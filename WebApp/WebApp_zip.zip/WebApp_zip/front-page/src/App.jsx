import { useState, useEffect } from 'react'
// import reactLogo from './assets/react.svg'
import Sidebar from './Sidebar';
import DrawPlot from './DrawPlot';
import './App.css'

function App() {
  const [selectedData, setSelectedData] = useState('home_data');
  const [data, setData] = useState(null);
  const [smooth, setSmooth] = useState(0.6);

  useEffect(() => {
      fetch(`/api/data/${selectedData}`)
          .then(response => response.json())
          .then(data => setData(data));
  }, [selectedData]);

  return (
    <div className="App">
      <Sidebar 
            setSelectedData={setSelectedData} 
            selectedData={selectedData}
            smooth={smooth} 
            setSmooth={setSmooth}
      />
      <DrawPlot data={data} smooth={smooth}/>
    </div>
  )
}

export default App

// DrawPlot.jsx
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

function calculateEMA(data, smooth) {
  let emaData = [];
  let multiplier = smooth / (1 + smooth);
  let previousEMA = data[0];

  for (let i = 0; i < data.length; i++) {
    let currentEMA = (data[i] - previousEMA) * multiplier + previousEMA;
    emaData.push(currentEMA);
    previousEMA = currentEMA;
  }

  return emaData;
}

const DrawPlot = ({ data, smooth }) => {
    if (!data) return null;

    const trainIouData = calculateEMA(data.train.iou, (1.0 - smooth));
    const evalIouData = calculateEMA(data.eval.iou, (1.0 - smooth));

    const iouData = trainIouData.map((value, index) => ({
      name: `${index}`, 
      train: value, 
      eval: evalIouData[index]
    }));

    const trainAccuData = calculateEMA(data.train.accu, (1.0 - smooth));
    const evalAccuData = calculateEMA(data.eval.accu, (1.0 - smooth));

    const accuData = trainAccuData.map((value, index) => ({
      name: `${index}`, 
      train: value, 
      eval: evalAccuData[index]
    }));

    const trainLossData = calculateEMA(data.train.loss, (1.0 - smooth));
    const evalLossData = calculateEMA(data.eval.loss, (1.0 - smooth));

    const lossData = trainLossData.map((value, index) => ({
      name: `${index}`, 
      train: value, 
      eval: evalLossData[index]
    }));

    return (
      <div className="mainwindow">
        <h3>IOU</h3>
        <LineChart
          width={500}
          height={300}
          data={iouData}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="train" stroke="#8884d8" dot={false} strokeWidth={3} />
          <Line type="monotone" dataKey="eval" stroke="#82ca9d" dot={false} strokeWidth={3} />
        </LineChart>

        <h3>Accu</h3>
        <LineChart
          width={500}
          height={300}
          data={accuData}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="train" stroke="#8884d8" dot={false} strokeWidth={3} />
          <Line type="monotone" dataKey="eval" stroke="#82ca9d" dot={false} strokeWidth={3} />
        </LineChart>

        <h3>Loss</h3>
        <LineChart
          width={500}
          height={300}
          data={lossData}
          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="train" stroke="#8884d8" dot={false} strokeWidth={3} />
          <Line type="monotone" dataKey="eval" stroke="#82ca9d" dot={false} strokeWidth={3} />
        </LineChart>
        
      </div>
    );
};

export default DrawPlot;

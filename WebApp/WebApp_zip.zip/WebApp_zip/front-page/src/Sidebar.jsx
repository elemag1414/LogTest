import React, { useState, useEffect } from 'react';
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';

function Sidebar({ selectedData, setSelectedData, smooth, setSmooth }) {
    const [data, setData] = useState(null);

    useEffect(() => {
      fetch(`/api/data/${selectedData}`)
          .then(response => response.json())  // 여기서 반환된 Promise를 다음 then에서 처리합니다.
          .then(data => {
              // console.log('Data: ', data)
              setData(data);
          });
    }, [selectedData]);

    return (
        <div className="sidebar">
            <h2>Menu</h2>
            <div className="slider">
                <h3>Smooth</h3>
                {/* <input type="range" min="0" max="10" value={smooth} onChange={(e) => setSmooth(e.target.value)} /> */}
                <input type="range" min="0.0" max="0.9" step="0.1" value={smooth} onChange={(e) => setSmooth(e.target.value)} />
                <p>{smooth}</p>
            </div>
            <div className="dropdown">
                <h3>Select Data</h3>
                <select value={selectedData} onChange={(e) => setSelectedData(e.target.value)}>
                    <option value="home_data">home_data</option>
                    <option value="electron_data">electron_data</option>
                </select>
            </div>
        </div>
    );
}

export default Sidebar;
import React, { useState, useEffect } from 'react';
import { Button, Select, Slider, Divider } from "antd";

function Sidebar({ selectedData, setSelectedData, smooth, setSmooth, setData }) {
    const menuItems = ['home_data', 'electron_data'];


    useEffect(() => {
        fetch(`/api/data/${selectedData}`)
            .then(response => response.json())  // 여기서 반환된 Promise를 다음 then에서 처리합니다.
            .then(data => {
                setData(data);
            });
    }, [selectedData]);

    const buttonHandler = (val) => {
        fetch(`/api/reload/${selectedData}`)
            .then(response => response.json())  // 여기서 반환된 Promise를 다음 then에서 처리합니다.
            .then(data => {
                const maxEvalF1 = Math.max(...data.eval.f1);
                const maxEvalF1Index = data.eval.f1.indexOf(maxEvalF1);
                console.log('Eval f1 Max: ', maxEvalF1, ' @', maxEvalF1Index+1);
                setData(data);
            });
    }

    return (
        <div className="sidebar">
            <Divider />
            <h2>Menu</h2>
            <Divider />
            <div className="slider">
                <h3>Smooth</h3>
                <Slider 
                    min={0.0} max={0.9} step={0.1} 
                    value={smooth} 
                    style={{width:'80%'}}
                    onChange={(value) => setSmooth(value)}
                ></Slider>
                <p>{smooth}</p>
            </div>
            <Divider />
            <div className="dropdown">
                <h3>Select Data</h3>
                
                <Select 
                    placeholder={selectedData}
                    style={{width:'80%'}}
                    defaultValue={menuItems[0].toUpperCase()}
                    onChange={(e) => setSelectedData(e)}
                >
                    {menuItems.map((menu, index) => {
                        return <Select.Option key={index} value={menu}>{menu.toUpperCase()}</Select.Option>
                    })}
                </Select>
            </div>
            <br />
            <div className='fetchbutton'>
                <Button type='primary' style={{width:'80%'}} onClick={buttonHandler}>Fetch Data</Button>
            </div>
        </div>
    );
}

export default Sidebar;
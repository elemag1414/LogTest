import { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import MainPanel from './MainPanel';
import './App.css'

function App() {
  const [selectedData, setSelectedData] = useState('home_data');
  const [data, setData] = useState(null);
  const [smooth, setSmooth] = useState(0.0);

  useEffect(() => {
    fetch(`/api/data/${selectedData}`)
        .then(response => response.json())
        .then(data => {
          // if ('f1' in data) {
          //   setData(data);
          // } else {
          //   data.eval['f1'] = null;
          //   setData(data);
          // }
          setData(data);
        });
  }, [selectedData]);

  return (
    <div className="App">
      <Sidebar 
            setSelectedData={setSelectedData} 
            selectedData={selectedData}
            smooth={smooth} 
            setSmooth={setSmooth}
            setData={setData}
      />
      {data && (<MainPanel data={data} smooth={smooth} selectedData={selectedData}/>)}
    </div>
  )
}

export default App

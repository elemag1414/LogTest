import os, json, re

def convert_log_new(file_name):
  with open(file_name, 'r') as f:
    lines = f.readlines()

  parsed_data = []
  lines_iter = iter(lines)

  for line in lines_iter:
    # parsed_data를 찾습니다.
    if line.startswith('@') or line.startswith('['):
      epoch_data = {}
      
      key, value = line[1:].split(' ', 1)  # 첫 번째 공백에서 분리합니다.
      
      # epoch 값을 파싱합니다.
      epoch = int(re.search(r'\d+', value).group())
      epoch_data['epoch'] = epoch
      
      # train과 eval 세션을 파싱합니다.
      for session in ['train', 'eval']:
        session_start = value.find(f'[{session.upper()}]') + len(session) + 3

        # "[EVAL]" 다음에 오는 "[...]" 문자열을 건너뛰기 위해 정규식을 사용합니다.
        if session == 'eval':
          next_bracket = re.search(r'\[.*?\]', value[session_start:])
          if next_bracket:
            session_start += next_bracket.end()
        
        session_end = value.find('[', session_start+1)

        if session_end == -1:
            session_end = None
        
        # print(f'{session} session start: {session_start}, end: {session_end}')

        session_str = value[session_start:session_end]
        session_items = session_str.split(', ')
        session_data = {}
        for item in session_items:
          try:
            k, v = item.split(': ')
            # "%"가 포함된 항목은 퍼센트를 제거하고 float으로 변환합니다.
            if '%' in v:
              v_index = v.find('%')
              v = v[:v_index]
              # print(f"removed % : {v}")
            # "ms" 또는 "m"가 포함된 항목은 무시합니다.
            elif 'ms' in v or 'm' in v:
              continue
            # iou 값은 공백을 제거하고 float으로 변환합니다.
            elif 'f1' in k:
              v = v.split(' ')[0]
            session_data[k.strip()] = float(v)

          except ValueError:
            # print('Value ERROR')
            pass
        
        epoch_data[session] = session_data
      
      parsed_data.append(epoch_data)

  train_accu = []
  train_iou = []
  train_f1 = []
  train_loss = []
  eval_accu = []
  eval_iou = []
  eval_f1 = []
  eval_loss = []
  for blob in parsed_data:
    train_accu.append(blob['train']['accu-50'])
    train_iou.append(blob['train']['iou'])
    train_loss.append(blob['train']['loss'])
    eval_accu.append(blob['eval']['accu-50'])
    eval_iou.append(blob['eval']['iou'])
    eval_loss.append(blob['eval']['loss'])

    if 'f1' in list(blob['train'].keys()):
      train_f1.append(blob['train']['f1'])
      eval_f1.append(blob['eval']['f1'])

  return {
            'train': 
                      {'accu': train_accu, 'iou': train_iou, 'loss': train_loss, 'f1': train_f1}, 
            'eval': 
                      {'accu': eval_accu, 'iou': eval_iou, 'loss': eval_loss, 'f1': eval_f1}
          }


if __name__ == "__main__":

  file_name = 'train_log_main_20230605_1912.txt'
  data = convert_log_new(file_name)
  print(json.dumps(data, indent=2))
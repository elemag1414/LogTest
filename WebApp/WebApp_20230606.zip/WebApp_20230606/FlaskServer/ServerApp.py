import os, re, json
from flask import Flask, jsonify
from Utils import convert_log_new
from termcolor import colored 

app = Flask(__name__)


def convert_log(file_name):
  with open(file_name, 'r') as f:
    # lines = f.read()
    lines = f.readlines()

  parsed_data = []
  lines_iter = iter(lines)

  for line in lines_iter:
    # parsed_data를 찾습니다.
    if line.startswith('@') or line.startswith('['):
      epoch_data = {}
      
      key, value = line[1:].split(' ', 1)  # 첫 번째 공백에서 분리합니다.
      
      # epoch 값을 파싱합니다.
      epoch = int(re.search(r'\d+', value).group())
      epoch_data['epoch'] = epoch
      
      # train과 eval 세션을 파싱합니다.
      for session in ['train', 'eval']:
        session_start = value.find(f'[{session.upper()}]') + len(session) + 3

        # "[EVAL]" 다음에 오는 "[...]" 문자열을 건너뛰기 위해 정규식을 사용합니다.
        if session == 'eval':
          next_bracket = re.search(r'\[.*?\]', value[session_start:])
          if next_bracket:
            session_start += next_bracket.end()
        
        session_end = value.find('[', session_start+1)

        if session_end == -1:
            session_end = None
        
        # print(f'{session} session start: {session_start}, end: {session_end}')

        session_str = value[session_start:session_end]
        session_items = session_str.split(', ')
        session_data = {}
        # print(session_items)
        for item in session_items:
          try:
            k, v = item.split(': ')
            # "%"가 포함된 항목은 퍼센트를 제거하고 float으로 변환합니다.
            if '%' in v:
              v_index = v.find('%')
              v = v[:v_index]
              # print(f"removed % : {v}")
            # "ms" 또는 "m"가 포함된 항목은 무시합니다.
            elif 'ms' in v or 'm' in v:
              continue
            # iou 값은 공백을 제거하고 float으로 변환합니다.
            elif 'iou' in k:
              # print(f"iou: {k}")
              v = v.split(' ')[0]
            session_data[k.strip()] = float(v)
          except ValueError:
            # print('Value ERROR')
            pass
        
        epoch_data[session] = session_data
      
      parsed_data.append(epoch_data)

  train_accu = []
  train_iou = []
  train_loss = []
  eval_accu = []
  eval_iou = []
  eval_loss = []
  for blob in parsed_data:
    train_accu.append(blob['train']['accu-50'])
    train_iou.append(blob['train']['iou'])
    train_loss.append(blob['train']['loss'])
    eval_accu.append(blob['eval']['accu-50'])
    eval_iou.append(blob['eval']['iou'])
    eval_loss.append(blob['eval']['loss'])

  return {'train': {'accu': train_accu, 'iou': train_iou, 'loss': train_loss}, 'eval': {'accu': eval_accu, 'iou': eval_iou, 'loss': eval_loss}}


@app.route('/data/home_data', methods=['GET'])
def get_home_data():
  print('fetch request home_data received')
  # print(home_data)
  return jsonify(home_data)

@app.route('/data/electron_data', methods=['GET'])
def get_electron_data():
  print('fetch request for electron_data received')
  return jsonify(electron_data)

@app.route('/reload/home_data', methods=['GET'])
def reload():
  global home_data
  print('Reload Data...')
  home_data = convert_log_new(home_log_file)
  return jsonify(home_data)


if __name__ == '__main__':

  # New Log Files
  home_log_file = os.path.join(os.path.dirname(__file__), 'logs', 'train_log_main_20230605_1912.txt')
  electron_log_file = os.path.join(os.path.dirname(__file__), 'logs', 'train_log_electron.log')

  assert os.path.exists(home_log_file), colored('home file not found', 'red')
  assert os.path.exists(electron_log_file), colored('home file not found', 'red')

  home_data = convert_log_new(home_log_file)
  print("HOME Data: \n", json.dumps(home_data, indent=2))
  electron_data = convert_log(electron_log_file)
  app.run(host='0.0.0.0', port=5000, debug=True)
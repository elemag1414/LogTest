import os, json 
from GitHubUtils import (
                          set_github_obj,
                          github_ll,
                          github_create_file,
                          github_file_content
                        )
from Utils import convert_log_new
from termcolor import colored
import argparse, time

# Initialize parser
parser = argparse.ArgumentParser()

# Adding optional argument
parser.add_argument("--fetch", action='store_true', help="Set fetch flag")

# Parse the arguments
args = parser.parse_args()

github_fetch = args.fetch

def create_dir(path):
  if not os.path.exists(path):
    os.makedirs(path)

def cprint(msg, color='white'):
  print(colored(msg, color=color)) 

if __name__ == '__main__':

  set_github_obj()

  etri_log_file = github_ll(dir='logs')[0]

  print(etri_log_file)

  log_folder = os.path.dirname(etri_log_file)
  create_dir(log_folder)
  log_file_name = os.path.basename(etri_log_file)

  if github_fetch:
    cprint('\nFetch Log Data Files', 'green')
    contents = github_file_content(etri_log_file)
    cprint('Fetch Done...', 'green')

    cprint('\nSave fetch Data')
    with open(etri_log_file, "w") as f:
      [f.write(f"{x}\n") for x in contents.split('\n')]
    time.sleep(1)

    lastLine = [x.strip() for x in contents.split('\n')[-3:]]
    print(f"Last Line:")
    [print(x) for x in lastLine]
    if os.path.exists(os.path.join(log_folder, 'lastEpoch.txt')):
      with open(os.path.join(log_folder, 'lastEpoch.txt'), 'r') as f:
        cprint(f"\nPrev Epochs", "green")
        [print(x.strip()) for x in f.readlines()]
      time.sleep(1)
    else:
      print("\nPrev Epochs Info Not Found")

  newData = convert_log_new(etri_log_file)

  with open(os.path.join(log_folder, 'lastEpoch.txt'), 'w') as f:
    etri_epoch = len(newData['eval']['f1'])
    cprint(f"\nThis Epochs", "green")
    f.write(f'electron: NA\n')
    f.write(f'etri: {etri_epoch}\n')
    print(f'electron: NA')
    print(f'etri: {etri_epoch}')


